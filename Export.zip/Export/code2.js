gdjs.Space_95sceneCode = {};
gdjs.Space_95sceneCode.localVariables = [];
gdjs.Space_95sceneCode.idToCallbackMap = new Map();
gdjs.Space_95sceneCode.forEachIndex3 = 0;

gdjs.Space_95sceneCode.forEachObjects3 = [];

gdjs.Space_95sceneCode.forEachTemporary3 = null;

gdjs.Space_95sceneCode.forEachTotalCount3 = 0;

gdjs.Space_95sceneCode.GDShipObjects1= [];
gdjs.Space_95sceneCode.GDShipObjects2= [];
gdjs.Space_95sceneCode.GDShipObjects3= [];
gdjs.Space_95sceneCode.GDShipObjects4= [];
gdjs.Space_95sceneCode.GDAestroidsObjects1= [];
gdjs.Space_95sceneCode.GDAestroidsObjects2= [];
gdjs.Space_95sceneCode.GDAestroidsObjects3= [];
gdjs.Space_95sceneCode.GDAestroidsObjects4= [];
gdjs.Space_95sceneCode.GDAstroCurrencyObjects1= [];
gdjs.Space_95sceneCode.GDAstroCurrencyObjects2= [];
gdjs.Space_95sceneCode.GDAstroCurrencyObjects3= [];
gdjs.Space_95sceneCode.GDAstroCurrencyObjects4= [];
gdjs.Space_95sceneCode.GDSpawnerObjects1= [];
gdjs.Space_95sceneCode.GDSpawnerObjects2= [];
gdjs.Space_95sceneCode.GDSpawnerObjects3= [];
gdjs.Space_95sceneCode.GDSpawnerObjects4= [];
gdjs.Space_95sceneCode.GDboundaryObjects1= [];
gdjs.Space_95sceneCode.GDboundaryObjects2= [];
gdjs.Space_95sceneCode.GDboundaryObjects3= [];
gdjs.Space_95sceneCode.GDboundaryObjects4= [];
gdjs.Space_95sceneCode.GDbgObjects1= [];
gdjs.Space_95sceneCode.GDbgObjects2= [];
gdjs.Space_95sceneCode.GDbgObjects3= [];
gdjs.Space_95sceneCode.GDbgObjects4= [];
gdjs.Space_95sceneCode.GDRedFlatBarObjects1= [];
gdjs.Space_95sceneCode.GDRedFlatBarObjects2= [];
gdjs.Space_95sceneCode.GDRedFlatBarObjects3= [];
gdjs.Space_95sceneCode.GDRedFlatBarObjects4= [];
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects1= [];
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects2= [];
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects3= [];
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects4= [];
gdjs.Space_95sceneCode.GDAstroTextObjects1= [];
gdjs.Space_95sceneCode.GDAstroTextObjects2= [];
gdjs.Space_95sceneCode.GDAstroTextObjects3= [];
gdjs.Space_95sceneCode.GDAstroTextObjects4= [];
gdjs.Space_95sceneCode.GDEnergyTextObjects1= [];
gdjs.Space_95sceneCode.GDEnergyTextObjects2= [];
gdjs.Space_95sceneCode.GDEnergyTextObjects3= [];
gdjs.Space_95sceneCode.GDEnergyTextObjects4= [];
gdjs.Space_95sceneCode.GDRepairTextObjects1= [];
gdjs.Space_95sceneCode.GDRepairTextObjects2= [];
gdjs.Space_95sceneCode.GDRepairTextObjects3= [];
gdjs.Space_95sceneCode.GDRepairTextObjects4= [];
gdjs.Space_95sceneCode.GDAstroCurrency2Objects1= [];
gdjs.Space_95sceneCode.GDAstroCurrency2Objects2= [];
gdjs.Space_95sceneCode.GDAstroCurrency2Objects3= [];
gdjs.Space_95sceneCode.GDAstroCurrency2Objects4= [];
gdjs.Space_95sceneCode.GDBulletObjects1= [];
gdjs.Space_95sceneCode.GDBulletObjects2= [];
gdjs.Space_95sceneCode.GDBulletObjects3= [];
gdjs.Space_95sceneCode.GDBulletObjects4= [];
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects1= [];
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects2= [];
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects3= [];
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects4= [];


gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Space_95sceneCode.GDBulletObjects1});
gdjs.Space_95sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects2);
{for(var i = 0, len = gdjs.Space_95sceneCode.GDShipObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDShipObjects2[i].rotateTowardAngle((gdjs.Space_95sceneCode.GDShipObjects2[i].getAngleToPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0))), 350, runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects1);
gdjs.Space_95sceneCode.GDBulletObjects1.length = 0;

{for(var i = 0, len = gdjs.Space_95sceneCode.GDShipObjects1.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDShipObjects1[i].getBehavior("FireBullet").Fire((gdjs.Space_95sceneCode.GDShipObjects1[i].getPointX("Shoot")), (gdjs.Space_95sceneCode.GDShipObjects1[i].getPointY("Shoot")), gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDBulletObjects1Objects, (gdjs.Space_95sceneCode.GDShipObjects1[i].getAngle()), 400, null);
}
}
}

}


};gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDShipObjects2Objects = Hashtable.newFrom({"Ship": gdjs.Space_95sceneCode.GDShipObjects2});
gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAestroidsObjects2Objects = Hashtable.newFrom({"Aestroids": gdjs.Space_95sceneCode.GDAestroidsObjects2});
gdjs.Space_95sceneCode.asyncCallback19103724 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Space_95sceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Aestroids"), gdjs.Space_95sceneCode.GDAestroidsObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects3);

{for(var i = 0, len = gdjs.Space_95sceneCode.GDShipObjects3.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDShipObjects3[i].clearForces();
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAestroidsObjects3.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAestroidsObjects3[i].clearForces();
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDShipObjects3.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDShipObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(200);
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDShipObjects3.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDShipObjects3[i].getBehavior("Health").Hit(10, true, true, null);
}
}
gdjs.Space_95sceneCode.localVariables.length = 0;
}
gdjs.Space_95sceneCode.idToCallbackMap.set(19103724, gdjs.Space_95sceneCode.asyncCallback19103724);
gdjs.Space_95sceneCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Space_95sceneCode.localVariables);
for (const obj of gdjs.Space_95sceneCode.GDAestroidsObjects2) asyncObjectsList.addObject("Aestroids", obj);
for (const obj of gdjs.Space_95sceneCode.GDShipObjects2) asyncObjectsList.addObject("Ship", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.Space_95sceneCode.asyncCallback19103724(runtimeScene, asyncObjectsList)), 19103724, asyncObjectsList);
}
}

}


};gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Space_95sceneCode.GDBulletObjects2});
gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAestroidsObjects2Objects = Hashtable.newFrom({"Aestroids": gdjs.Space_95sceneCode.GDAestroidsObjects2});
gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAstroCurrencyObjects4Objects = Hashtable.newFrom({"AstroCurrency": gdjs.Space_95sceneCode.GDAstroCurrencyObjects4});
gdjs.Space_95sceneCode.eventsList2 = function(runtimeScene) {

};gdjs.Space_95sceneCode.eventsList3 = function(runtimeScene) {

{


const repeatCount4 = gdjs.randomInRange(1, 5);
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.Space_95sceneCode.GDAestroidsObjects2, gdjs.Space_95sceneCode.GDAestroidsObjects4);

gdjs.Space_95sceneCode.GDAstroCurrencyObjects4.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAstroCurrencyObjects4Objects, (( gdjs.Space_95sceneCode.GDAestroidsObjects4.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDAestroidsObjects4[0].getPointX("")), (( gdjs.Space_95sceneCode.GDAestroidsObjects4.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDAestroidsObjects4[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAstroCurrencyObjects4.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAstroCurrencyObjects4[i].addPolarForce(gdjs.randomFloatInRange(0, 360), 250, 0);
}
}
}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Space_95sceneCode.GDAestroidsObjects2 */
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAestroidsObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAestroidsObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDShipObjects2Objects = Hashtable.newFrom({"Ship": gdjs.Space_95sceneCode.GDShipObjects2});
gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAstroCurrencyObjects2Objects = Hashtable.newFrom({"AstroCurrency": gdjs.Space_95sceneCode.GDAstroCurrencyObjects2});
gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAestroidsObjects2Objects = Hashtable.newFrom({"Aestroids": gdjs.Space_95sceneCode.GDAestroidsObjects2});
gdjs.Space_95sceneCode.eventsList4 = function(runtimeScene) {

};gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDboundaryObjects1Objects = Hashtable.newFrom({"boundary": gdjs.Space_95sceneCode.GDboundaryObjects1});
gdjs.Space_95sceneCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Aestroids"), gdjs.Space_95sceneCode.GDAestroidsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDShipObjects2Objects, gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAestroidsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(19102564);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Space_95sceneCode.GDAestroidsObjects2 */
/* Reuse gdjs.Space_95sceneCode.GDShipObjects2 */
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.3, 0, 0.05, null);
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDShipObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDShipObjects2[i].getBehavior("TopDownMovement").setMaxSpeed(0);
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDShipObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDShipObjects2[i].clearForces();
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDShipObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDShipObjects2[i].addPolarForce(gdjs.evtTools.common.angleBetweenPositions((gdjs.Space_95sceneCode.GDShipObjects2[i].getPointX("")), (gdjs.Space_95sceneCode.GDShipObjects2[i].getPointY("")), (( gdjs.Space_95sceneCode.GDAestroidsObjects2.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDAestroidsObjects2[0].getPointX("")), (( gdjs.Space_95sceneCode.GDAestroidsObjects2.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDAestroidsObjects2[0].getPointY(""))) - 180, 75, 1);
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAestroidsObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAestroidsObjects2[i].addPolarForce(gdjs.evtTools.common.angleBetweenPositions((( gdjs.Space_95sceneCode.GDShipObjects2.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDShipObjects2[0].getPointX("")), (( gdjs.Space_95sceneCode.GDShipObjects2.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDShipObjects2[0].getPointY("")), (gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getPointX("")), (gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getPointY(""))), 75, 1);
}
}

{ //Subevents
gdjs.Space_95sceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Aestroids"), gdjs.Space_95sceneCode.GDAestroidsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Space_95sceneCode.GDBulletObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDBulletObjects2Objects, gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAestroidsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(19105636);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Space_95sceneCode.GDAestroidsObjects2 */
/* Reuse gdjs.Space_95sceneCode.GDBulletObjects2 */
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAestroidsObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getBehavior("Health").Hit(1, true, true, null);
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAestroidsObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.3, 5, 5, 5, 0.08, false, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Aestroids"), gdjs.Space_95sceneCode.GDAestroidsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Space_95sceneCode.GDAestroidsObjects2.length;i<l;++i) {
    if ( gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getBehavior("Health").IsDead(null) ) {
        isConditionTrue_0 = true;
        gdjs.Space_95sceneCode.GDAestroidsObjects2[k] = gdjs.Space_95sceneCode.GDAestroidsObjects2[i];
        ++k;
    }
}
gdjs.Space_95sceneCode.GDAestroidsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(19106460);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Space_95sceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroCurrency"), gdjs.Space_95sceneCode.GDAstroCurrencyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDShipObjects2Objects, gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAstroCurrencyObjects2Objects, 150, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Space_95sceneCode.GDAstroCurrencyObjects2 */
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAstroCurrencyObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAstroCurrencyObjects2[i].returnVariable(gdjs.Space_95sceneCode.GDAstroCurrencyObjects2[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroCurrency"), gdjs.Space_95sceneCode.GDAstroCurrencyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Space_95sceneCode.GDAstroCurrencyObjects2.length;i<l;++i) {
    if ( gdjs.Space_95sceneCode.GDAstroCurrencyObjects2[i].getVariableBoolean(gdjs.Space_95sceneCode.GDAstroCurrencyObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Space_95sceneCode.GDAstroCurrencyObjects2[k] = gdjs.Space_95sceneCode.GDAstroCurrencyObjects2[i];
        ++k;
    }
}
gdjs.Space_95sceneCode.GDAstroCurrencyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Space_95sceneCode.GDAstroCurrencyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects2);
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAstroCurrencyObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAstroCurrencyObjects2[i].addForceTowardObject((gdjs.Space_95sceneCode.GDShipObjects2.length !== 0 ? gdjs.Space_95sceneCode.GDShipObjects2[0] : null), 300, 0);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Aestroids"), gdjs.Space_95sceneCode.GDAestroidsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spawner"), gdjs.Space_95sceneCode.GDSpawnerObjects2);
{for(var i = 0, len = gdjs.Space_95sceneCode.GDSpawnerObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDSpawnerObjects2[i].getBehavior("ObjectSpawner").SpawnObject(gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAestroidsObjects2Objects, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Aestroids"), gdjs.Space_95sceneCode.GDAestroidsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Space_95sceneCode.GDAestroidsObjects2.length;i<l;++i) {
    if ( gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getVariableBoolean(gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getVariables().getFromIndex(1), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.Space_95sceneCode.GDAestroidsObjects2[k] = gdjs.Space_95sceneCode.GDAestroidsObjects2[i];
        ++k;
    }
}
gdjs.Space_95sceneCode.GDAestroidsObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Space_95sceneCode.GDAestroidsObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects2);
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAestroidsObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAestroidsObjects2[i].returnVariable(gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.common.angleBetweenPositions((( gdjs.Space_95sceneCode.GDShipObjects2.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDShipObjects2[0].getPointX("")), (( gdjs.Space_95sceneCode.GDShipObjects2.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDShipObjects2[0].getPointY("")), (gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getPointX("")), (gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getPointY(""))) + 180);
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAestroidsObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAestroidsObjects2[i].returnVariable(gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Aestroids"), gdjs.Space_95sceneCode.GDAestroidsObjects2);
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAestroidsObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAestroidsObjects2[i].addPolarForce(gdjs.Space_95sceneCode.GDAestroidsObjects2[i].getVariables().getFromIndex(0).getAsNumber(), gdjs.randomInRange(30, 90), 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Spawner"), gdjs.Space_95sceneCode.GDSpawnerObjects2);

for (gdjs.Space_95sceneCode.forEachIndex3 = 0;gdjs.Space_95sceneCode.forEachIndex3 < gdjs.Space_95sceneCode.GDSpawnerObjects2.length;++gdjs.Space_95sceneCode.forEachIndex3) {
gdjs.Space_95sceneCode.GDSpawnerObjects3.length = 0;


gdjs.Space_95sceneCode.forEachTemporary3 = gdjs.Space_95sceneCode.GDSpawnerObjects2[gdjs.Space_95sceneCode.forEachIndex3];
gdjs.Space_95sceneCode.GDSpawnerObjects3.push(gdjs.Space_95sceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Space_95sceneCode.GDSpawnerObjects3.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDSpawnerObjects3[i].getBehavior("ObjectSpawner").SetSpawnPeriod(gdjs.randomFloatInRange(2, 5), null);
}
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects2);
gdjs.copyArray(runtimeScene.getObjects("TinySquareRedBar"), gdjs.Space_95sceneCode.GDTinySquareRedBarObjects2);
{for(var i = 0, len = gdjs.Space_95sceneCode.GDTinySquareRedBarObjects2.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDTinySquareRedBarObjects2[i].SetValue((( gdjs.Space_95sceneCode.GDShipObjects2.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDShipObjects2[0].getBehavior("Health").Health(null)), null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects1);
gdjs.copyArray(runtimeScene.getObjects("boundary"), gdjs.Space_95sceneCode.GDboundaryObjects1);
{for(var i = 0, len = gdjs.Space_95sceneCode.GDboundaryObjects1.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDboundaryObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDShipObjects1.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDShipObjects1[i].separateFromObjectsList(gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDboundaryObjects1Objects, false);
}
}
}

}


};gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAstroCurrencyObjects1Objects = Hashtable.newFrom({"AstroCurrency": gdjs.Space_95sceneCode.GDAstroCurrencyObjects1});
gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDShipObjects1Objects = Hashtable.newFrom({"Ship": gdjs.Space_95sceneCode.GDShipObjects1});
gdjs.Space_95sceneCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Space_95sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Space_95sceneCode.GDBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Space_95sceneCode.GDBulletObjects1.length;i<l;++i) {
    if ( !(gdjs.Space_95sceneCode.GDBulletObjects1[i].getBehavior("InOnScreen").IsOnScreen(20, null)) ) {
        isConditionTrue_0 = true;
        gdjs.Space_95sceneCode.GDBulletObjects1[k] = gdjs.Space_95sceneCode.GDBulletObjects1[i];
        ++k;
    }
}
gdjs.Space_95sceneCode.GDBulletObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Space_95sceneCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.Space_95sceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


gdjs.Space_95sceneCode.eventsList5(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber((( gdjs.Space_95sceneCode.GDShipObjects1.length === 0 ) ? 0 :gdjs.Space_95sceneCode.GDShipObjects1[0].getBehavior("Health").Health(null)));
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Planet_scene", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroCurrency"), gdjs.Space_95sceneCode.GDAstroCurrencyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Ship"), gdjs.Space_95sceneCode.GDShipObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDAstroCurrencyObjects1Objects, gdjs.Space_95sceneCode.mapOfGDgdjs_9546Space_959595sceneCode_9546GDShipObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Space_95sceneCode.GDAstroCurrencyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("AstroText"), gdjs.Space_95sceneCode.GDAstroTextObjects1);
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAstroCurrencyObjects1.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAstroCurrencyObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(6).add(1);
}
{for(var i = 0, len = gdjs.Space_95sceneCode.GDAstroTextObjects1.length ;i < len;++i) {
    gdjs.Space_95sceneCode.GDAstroTextObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Space_95sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Space_95sceneCode.GDShipObjects1.length = 0;
gdjs.Space_95sceneCode.GDShipObjects2.length = 0;
gdjs.Space_95sceneCode.GDShipObjects3.length = 0;
gdjs.Space_95sceneCode.GDShipObjects4.length = 0;
gdjs.Space_95sceneCode.GDAestroidsObjects1.length = 0;
gdjs.Space_95sceneCode.GDAestroidsObjects2.length = 0;
gdjs.Space_95sceneCode.GDAestroidsObjects3.length = 0;
gdjs.Space_95sceneCode.GDAestroidsObjects4.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrencyObjects1.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrencyObjects2.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrencyObjects3.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrencyObjects4.length = 0;
gdjs.Space_95sceneCode.GDSpawnerObjects1.length = 0;
gdjs.Space_95sceneCode.GDSpawnerObjects2.length = 0;
gdjs.Space_95sceneCode.GDSpawnerObjects3.length = 0;
gdjs.Space_95sceneCode.GDSpawnerObjects4.length = 0;
gdjs.Space_95sceneCode.GDboundaryObjects1.length = 0;
gdjs.Space_95sceneCode.GDboundaryObjects2.length = 0;
gdjs.Space_95sceneCode.GDboundaryObjects3.length = 0;
gdjs.Space_95sceneCode.GDboundaryObjects4.length = 0;
gdjs.Space_95sceneCode.GDbgObjects1.length = 0;
gdjs.Space_95sceneCode.GDbgObjects2.length = 0;
gdjs.Space_95sceneCode.GDbgObjects3.length = 0;
gdjs.Space_95sceneCode.GDbgObjects4.length = 0;
gdjs.Space_95sceneCode.GDRedFlatBarObjects1.length = 0;
gdjs.Space_95sceneCode.GDRedFlatBarObjects2.length = 0;
gdjs.Space_95sceneCode.GDRedFlatBarObjects3.length = 0;
gdjs.Space_95sceneCode.GDRedFlatBarObjects4.length = 0;
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects1.length = 0;
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects2.length = 0;
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects3.length = 0;
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects4.length = 0;
gdjs.Space_95sceneCode.GDAstroTextObjects1.length = 0;
gdjs.Space_95sceneCode.GDAstroTextObjects2.length = 0;
gdjs.Space_95sceneCode.GDAstroTextObjects3.length = 0;
gdjs.Space_95sceneCode.GDAstroTextObjects4.length = 0;
gdjs.Space_95sceneCode.GDEnergyTextObjects1.length = 0;
gdjs.Space_95sceneCode.GDEnergyTextObjects2.length = 0;
gdjs.Space_95sceneCode.GDEnergyTextObjects3.length = 0;
gdjs.Space_95sceneCode.GDEnergyTextObjects4.length = 0;
gdjs.Space_95sceneCode.GDRepairTextObjects1.length = 0;
gdjs.Space_95sceneCode.GDRepairTextObjects2.length = 0;
gdjs.Space_95sceneCode.GDRepairTextObjects3.length = 0;
gdjs.Space_95sceneCode.GDRepairTextObjects4.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrency2Objects1.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrency2Objects2.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrency2Objects3.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrency2Objects4.length = 0;
gdjs.Space_95sceneCode.GDBulletObjects1.length = 0;
gdjs.Space_95sceneCode.GDBulletObjects2.length = 0;
gdjs.Space_95sceneCode.GDBulletObjects3.length = 0;
gdjs.Space_95sceneCode.GDBulletObjects4.length = 0;
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects1.length = 0;
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects2.length = 0;
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects3.length = 0;
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects4.length = 0;

gdjs.Space_95sceneCode.eventsList6(runtimeScene);
gdjs.Space_95sceneCode.GDShipObjects1.length = 0;
gdjs.Space_95sceneCode.GDShipObjects2.length = 0;
gdjs.Space_95sceneCode.GDShipObjects3.length = 0;
gdjs.Space_95sceneCode.GDShipObjects4.length = 0;
gdjs.Space_95sceneCode.GDAestroidsObjects1.length = 0;
gdjs.Space_95sceneCode.GDAestroidsObjects2.length = 0;
gdjs.Space_95sceneCode.GDAestroidsObjects3.length = 0;
gdjs.Space_95sceneCode.GDAestroidsObjects4.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrencyObjects1.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrencyObjects2.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrencyObjects3.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrencyObjects4.length = 0;
gdjs.Space_95sceneCode.GDSpawnerObjects1.length = 0;
gdjs.Space_95sceneCode.GDSpawnerObjects2.length = 0;
gdjs.Space_95sceneCode.GDSpawnerObjects3.length = 0;
gdjs.Space_95sceneCode.GDSpawnerObjects4.length = 0;
gdjs.Space_95sceneCode.GDboundaryObjects1.length = 0;
gdjs.Space_95sceneCode.GDboundaryObjects2.length = 0;
gdjs.Space_95sceneCode.GDboundaryObjects3.length = 0;
gdjs.Space_95sceneCode.GDboundaryObjects4.length = 0;
gdjs.Space_95sceneCode.GDbgObjects1.length = 0;
gdjs.Space_95sceneCode.GDbgObjects2.length = 0;
gdjs.Space_95sceneCode.GDbgObjects3.length = 0;
gdjs.Space_95sceneCode.GDbgObjects4.length = 0;
gdjs.Space_95sceneCode.GDRedFlatBarObjects1.length = 0;
gdjs.Space_95sceneCode.GDRedFlatBarObjects2.length = 0;
gdjs.Space_95sceneCode.GDRedFlatBarObjects3.length = 0;
gdjs.Space_95sceneCode.GDRedFlatBarObjects4.length = 0;
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects1.length = 0;
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects2.length = 0;
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects3.length = 0;
gdjs.Space_95sceneCode.GDTinySquareRedBarObjects4.length = 0;
gdjs.Space_95sceneCode.GDAstroTextObjects1.length = 0;
gdjs.Space_95sceneCode.GDAstroTextObjects2.length = 0;
gdjs.Space_95sceneCode.GDAstroTextObjects3.length = 0;
gdjs.Space_95sceneCode.GDAstroTextObjects4.length = 0;
gdjs.Space_95sceneCode.GDEnergyTextObjects1.length = 0;
gdjs.Space_95sceneCode.GDEnergyTextObjects2.length = 0;
gdjs.Space_95sceneCode.GDEnergyTextObjects3.length = 0;
gdjs.Space_95sceneCode.GDEnergyTextObjects4.length = 0;
gdjs.Space_95sceneCode.GDRepairTextObjects1.length = 0;
gdjs.Space_95sceneCode.GDRepairTextObjects2.length = 0;
gdjs.Space_95sceneCode.GDRepairTextObjects3.length = 0;
gdjs.Space_95sceneCode.GDRepairTextObjects4.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrency2Objects1.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrency2Objects2.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrency2Objects3.length = 0;
gdjs.Space_95sceneCode.GDAstroCurrency2Objects4.length = 0;
gdjs.Space_95sceneCode.GDBulletObjects1.length = 0;
gdjs.Space_95sceneCode.GDBulletObjects2.length = 0;
gdjs.Space_95sceneCode.GDBulletObjects3.length = 0;
gdjs.Space_95sceneCode.GDBulletObjects4.length = 0;
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects1.length = 0;
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects2.length = 0;
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects3.length = 0;
gdjs.Space_95sceneCode.GDPlanet_9595floorObjects4.length = 0;


return;

}

gdjs['Space_95sceneCode'] = gdjs.Space_95sceneCode;
