gdjs.Main_95MenuCode = {};
gdjs.Main_95MenuCode.localVariables = [];
gdjs.Main_95MenuCode.idToCallbackMap = new Map();
gdjs.Main_95MenuCode.GDNewSpriteObjects1= [];
gdjs.Main_95MenuCode.GDNewSpriteObjects2= [];
gdjs.Main_95MenuCode.GDhhObjects1= [];
gdjs.Main_95MenuCode.GDhhObjects2= [];
gdjs.Main_95MenuCode.GDPLayObjects1= [];
gdjs.Main_95MenuCode.GDPLayObjects2= [];
gdjs.Main_95MenuCode.GDAstroTextObjects1= [];
gdjs.Main_95MenuCode.GDAstroTextObjects2= [];
gdjs.Main_95MenuCode.GDEnergyTextObjects1= [];
gdjs.Main_95MenuCode.GDEnergyTextObjects2= [];
gdjs.Main_95MenuCode.GDRepairTextObjects1= [];
gdjs.Main_95MenuCode.GDRepairTextObjects2= [];
gdjs.Main_95MenuCode.GDAstroCurrency2Objects1= [];
gdjs.Main_95MenuCode.GDAstroCurrency2Objects2= [];
gdjs.Main_95MenuCode.GDBulletObjects1= [];
gdjs.Main_95MenuCode.GDBulletObjects2= [];
gdjs.Main_95MenuCode.GDPlanet_9595floorObjects1= [];
gdjs.Main_95MenuCode.GDPlanet_9595floorObjects2= [];


gdjs.Main_95MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PLay"), gdjs.Main_95MenuCode.GDPLayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_95MenuCode.GDPLayObjects1.length;i<l;++i) {
    if ( gdjs.Main_95MenuCode.GDPLayObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_95MenuCode.GDPLayObjects1[k] = gdjs.Main_95MenuCode.GDPLayObjects1[i];
        ++k;
    }
}
gdjs.Main_95MenuCode.GDPLayObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Planet_scene", false);
}
}

}


};

gdjs.Main_95MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_95MenuCode.GDNewSpriteObjects1.length = 0;
gdjs.Main_95MenuCode.GDNewSpriteObjects2.length = 0;
gdjs.Main_95MenuCode.GDhhObjects1.length = 0;
gdjs.Main_95MenuCode.GDhhObjects2.length = 0;
gdjs.Main_95MenuCode.GDPLayObjects1.length = 0;
gdjs.Main_95MenuCode.GDPLayObjects2.length = 0;
gdjs.Main_95MenuCode.GDAstroTextObjects1.length = 0;
gdjs.Main_95MenuCode.GDAstroTextObjects2.length = 0;
gdjs.Main_95MenuCode.GDEnergyTextObjects1.length = 0;
gdjs.Main_95MenuCode.GDEnergyTextObjects2.length = 0;
gdjs.Main_95MenuCode.GDRepairTextObjects1.length = 0;
gdjs.Main_95MenuCode.GDRepairTextObjects2.length = 0;
gdjs.Main_95MenuCode.GDAstroCurrency2Objects1.length = 0;
gdjs.Main_95MenuCode.GDAstroCurrency2Objects2.length = 0;
gdjs.Main_95MenuCode.GDBulletObjects1.length = 0;
gdjs.Main_95MenuCode.GDBulletObjects2.length = 0;
gdjs.Main_95MenuCode.GDPlanet_9595floorObjects1.length = 0;
gdjs.Main_95MenuCode.GDPlanet_9595floorObjects2.length = 0;

gdjs.Main_95MenuCode.eventsList0(runtimeScene);
gdjs.Main_95MenuCode.GDNewSpriteObjects1.length = 0;
gdjs.Main_95MenuCode.GDNewSpriteObjects2.length = 0;
gdjs.Main_95MenuCode.GDhhObjects1.length = 0;
gdjs.Main_95MenuCode.GDhhObjects2.length = 0;
gdjs.Main_95MenuCode.GDPLayObjects1.length = 0;
gdjs.Main_95MenuCode.GDPLayObjects2.length = 0;
gdjs.Main_95MenuCode.GDAstroTextObjects1.length = 0;
gdjs.Main_95MenuCode.GDAstroTextObjects2.length = 0;
gdjs.Main_95MenuCode.GDEnergyTextObjects1.length = 0;
gdjs.Main_95MenuCode.GDEnergyTextObjects2.length = 0;
gdjs.Main_95MenuCode.GDRepairTextObjects1.length = 0;
gdjs.Main_95MenuCode.GDRepairTextObjects2.length = 0;
gdjs.Main_95MenuCode.GDAstroCurrency2Objects1.length = 0;
gdjs.Main_95MenuCode.GDAstroCurrency2Objects2.length = 0;
gdjs.Main_95MenuCode.GDBulletObjects1.length = 0;
gdjs.Main_95MenuCode.GDBulletObjects2.length = 0;
gdjs.Main_95MenuCode.GDPlanet_9595floorObjects1.length = 0;
gdjs.Main_95MenuCode.GDPlanet_9595floorObjects2.length = 0;


return;

}

gdjs['Main_95MenuCode'] = gdjs.Main_95MenuCode;
