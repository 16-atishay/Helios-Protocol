gdjs.Planet_95sceneCode = {};
gdjs.Planet_95sceneCode.localVariables = [];
gdjs.Planet_95sceneCode.idToCallbackMap = new Map();
gdjs.Planet_95sceneCode.forEachCount0_3 = 0;

gdjs.Planet_95sceneCode.forEachCount1_3 = 0;

gdjs.Planet_95sceneCode.forEachCount2_3 = 0;

gdjs.Planet_95sceneCode.forEachCount3_3 = 0;

gdjs.Planet_95sceneCode.forEachIndex2 = 0;

gdjs.Planet_95sceneCode.forEachIndex3 = 0;

gdjs.Planet_95sceneCode.forEachIndex4 = 0;

gdjs.Planet_95sceneCode.forEachObjects2 = [];

gdjs.Planet_95sceneCode.forEachObjects3 = [];

gdjs.Planet_95sceneCode.forEachObjects4 = [];

gdjs.Planet_95sceneCode.forEachTemporary2 = null;

gdjs.Planet_95sceneCode.forEachTemporary3 = null;

gdjs.Planet_95sceneCode.forEachTemporary4 = null;

gdjs.Planet_95sceneCode.forEachTotalCount2 = 0;

gdjs.Planet_95sceneCode.forEachTotalCount3 = 0;

gdjs.Planet_95sceneCode.forEachTotalCount4 = 0;

gdjs.Planet_95sceneCode.GDPlayerObjects1= [];
gdjs.Planet_95sceneCode.GDPlayerObjects2= [];
gdjs.Planet_95sceneCode.GDPlayerObjects3= [];
gdjs.Planet_95sceneCode.GDPlayerObjects4= [];
gdjs.Planet_95sceneCode.GDPlayerObjects5= [];
gdjs.Planet_95sceneCode.GDPlayerObjects6= [];
gdjs.Planet_95sceneCode.GDPlayerObjects7= [];
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects1= [];
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects2= [];
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects3= [];
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects4= [];
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects5= [];
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects6= [];
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects7= [];
gdjs.Planet_95sceneCode.GDInventoryObjects1= [];
gdjs.Planet_95sceneCode.GDInventoryObjects2= [];
gdjs.Planet_95sceneCode.GDInventoryObjects3= [];
gdjs.Planet_95sceneCode.GDInventoryObjects4= [];
gdjs.Planet_95sceneCode.GDInventoryObjects5= [];
gdjs.Planet_95sceneCode.GDInventoryObjects6= [];
gdjs.Planet_95sceneCode.GDInventoryObjects7= [];
gdjs.Planet_95sceneCode.GDSolarObjects1= [];
gdjs.Planet_95sceneCode.GDSolarObjects2= [];
gdjs.Planet_95sceneCode.GDSolarObjects3= [];
gdjs.Planet_95sceneCode.GDSolarObjects4= [];
gdjs.Planet_95sceneCode.GDSolarObjects5= [];
gdjs.Planet_95sceneCode.GDSolarObjects6= [];
gdjs.Planet_95sceneCode.GDSolarObjects7= [];
gdjs.Planet_95sceneCode.GDSolarHObjects1= [];
gdjs.Planet_95sceneCode.GDSolarHObjects2= [];
gdjs.Planet_95sceneCode.GDSolarHObjects3= [];
gdjs.Planet_95sceneCode.GDSolarHObjects4= [];
gdjs.Planet_95sceneCode.GDSolarHObjects5= [];
gdjs.Planet_95sceneCode.GDSolarHObjects6= [];
gdjs.Planet_95sceneCode.GDSolarHObjects7= [];
gdjs.Planet_95sceneCode.GDDrillHObjects1= [];
gdjs.Planet_95sceneCode.GDDrillHObjects2= [];
gdjs.Planet_95sceneCode.GDDrillHObjects3= [];
gdjs.Planet_95sceneCode.GDDrillHObjects4= [];
gdjs.Planet_95sceneCode.GDDrillHObjects5= [];
gdjs.Planet_95sceneCode.GDDrillHObjects6= [];
gdjs.Planet_95sceneCode.GDDrillHObjects7= [];
gdjs.Planet_95sceneCode.GDDrillObjects1= [];
gdjs.Planet_95sceneCode.GDDrillObjects2= [];
gdjs.Planet_95sceneCode.GDDrillObjects3= [];
gdjs.Planet_95sceneCode.GDDrillObjects4= [];
gdjs.Planet_95sceneCode.GDDrillObjects5= [];
gdjs.Planet_95sceneCode.GDDrillObjects6= [];
gdjs.Planet_95sceneCode.GDDrillObjects7= [];
gdjs.Planet_95sceneCode.GDWindmillHObjects1= [];
gdjs.Planet_95sceneCode.GDWindmillHObjects2= [];
gdjs.Planet_95sceneCode.GDWindmillHObjects3= [];
gdjs.Planet_95sceneCode.GDWindmillHObjects4= [];
gdjs.Planet_95sceneCode.GDWindmillHObjects5= [];
gdjs.Planet_95sceneCode.GDWindmillHObjects6= [];
gdjs.Planet_95sceneCode.GDWindmillHObjects7= [];
gdjs.Planet_95sceneCode.GDWindmillObjects1= [];
gdjs.Planet_95sceneCode.GDWindmillObjects2= [];
gdjs.Planet_95sceneCode.GDWindmillObjects3= [];
gdjs.Planet_95sceneCode.GDWindmillObjects4= [];
gdjs.Planet_95sceneCode.GDWindmillObjects5= [];
gdjs.Planet_95sceneCode.GDWindmillObjects6= [];
gdjs.Planet_95sceneCode.GDWindmillObjects7= [];
gdjs.Planet_95sceneCode.GDShieldHObjects1= [];
gdjs.Planet_95sceneCode.GDShieldHObjects2= [];
gdjs.Planet_95sceneCode.GDShieldHObjects3= [];
gdjs.Planet_95sceneCode.GDShieldHObjects4= [];
gdjs.Planet_95sceneCode.GDShieldHObjects5= [];
gdjs.Planet_95sceneCode.GDShieldHObjects6= [];
gdjs.Planet_95sceneCode.GDShieldHObjects7= [];
gdjs.Planet_95sceneCode.GDShieldObjects1= [];
gdjs.Planet_95sceneCode.GDShieldObjects2= [];
gdjs.Planet_95sceneCode.GDShieldObjects3= [];
gdjs.Planet_95sceneCode.GDShieldObjects4= [];
gdjs.Planet_95sceneCode.GDShieldObjects5= [];
gdjs.Planet_95sceneCode.GDShieldObjects6= [];
gdjs.Planet_95sceneCode.GDShieldObjects7= [];
gdjs.Planet_95sceneCode.GDCraftObjects1= [];
gdjs.Planet_95sceneCode.GDCraftObjects2= [];
gdjs.Planet_95sceneCode.GDCraftObjects3= [];
gdjs.Planet_95sceneCode.GDCraftObjects4= [];
gdjs.Planet_95sceneCode.GDCraftObjects5= [];
gdjs.Planet_95sceneCode.GDCraftObjects6= [];
gdjs.Planet_95sceneCode.GDCraftObjects7= [];
gdjs.Planet_95sceneCode.GDBuyObjects1= [];
gdjs.Planet_95sceneCode.GDBuyObjects2= [];
gdjs.Planet_95sceneCode.GDBuyObjects3= [];
gdjs.Planet_95sceneCode.GDBuyObjects4= [];
gdjs.Planet_95sceneCode.GDBuyObjects5= [];
gdjs.Planet_95sceneCode.GDBuyObjects6= [];
gdjs.Planet_95sceneCode.GDBuyObjects7= [];
gdjs.Planet_95sceneCode.GDCloseBuyObjects1= [];
gdjs.Planet_95sceneCode.GDCloseBuyObjects2= [];
gdjs.Planet_95sceneCode.GDCloseBuyObjects3= [];
gdjs.Planet_95sceneCode.GDCloseBuyObjects4= [];
gdjs.Planet_95sceneCode.GDCloseBuyObjects5= [];
gdjs.Planet_95sceneCode.GDCloseBuyObjects6= [];
gdjs.Planet_95sceneCode.GDCloseBuyObjects7= [];
gdjs.Planet_95sceneCode.GDRocksObjects1= [];
gdjs.Planet_95sceneCode.GDRocksObjects2= [];
gdjs.Planet_95sceneCode.GDRocksObjects3= [];
gdjs.Planet_95sceneCode.GDRocksObjects4= [];
gdjs.Planet_95sceneCode.GDRocksObjects5= [];
gdjs.Planet_95sceneCode.GDRocksObjects6= [];
gdjs.Planet_95sceneCode.GDRocksObjects7= [];
gdjs.Planet_95sceneCode.GDtransObjects1= [];
gdjs.Planet_95sceneCode.GDtransObjects2= [];
gdjs.Planet_95sceneCode.GDtransObjects3= [];
gdjs.Planet_95sceneCode.GDtransObjects4= [];
gdjs.Planet_95sceneCode.GDtransObjects5= [];
gdjs.Planet_95sceneCode.GDtransObjects6= [];
gdjs.Planet_95sceneCode.GDtransObjects7= [];
gdjs.Planet_95sceneCode.GDInventoryTextObjects1= [];
gdjs.Planet_95sceneCode.GDInventoryTextObjects2= [];
gdjs.Planet_95sceneCode.GDInventoryTextObjects3= [];
gdjs.Planet_95sceneCode.GDInventoryTextObjects4= [];
gdjs.Planet_95sceneCode.GDInventoryTextObjects5= [];
gdjs.Planet_95sceneCode.GDInventoryTextObjects6= [];
gdjs.Planet_95sceneCode.GDInventoryTextObjects7= [];
gdjs.Planet_95sceneCode.GDBuyTextObjects1= [];
gdjs.Planet_95sceneCode.GDBuyTextObjects2= [];
gdjs.Planet_95sceneCode.GDBuyTextObjects3= [];
gdjs.Planet_95sceneCode.GDBuyTextObjects4= [];
gdjs.Planet_95sceneCode.GDBuyTextObjects5= [];
gdjs.Planet_95sceneCode.GDBuyTextObjects6= [];
gdjs.Planet_95sceneCode.GDBuyTextObjects7= [];
gdjs.Planet_95sceneCode.GDBuyText2Objects1= [];
gdjs.Planet_95sceneCode.GDBuyText2Objects2= [];
gdjs.Planet_95sceneCode.GDBuyText2Objects3= [];
gdjs.Planet_95sceneCode.GDBuyText2Objects4= [];
gdjs.Planet_95sceneCode.GDBuyText2Objects5= [];
gdjs.Planet_95sceneCode.GDBuyText2Objects6= [];
gdjs.Planet_95sceneCode.GDBuyText2Objects7= [];
gdjs.Planet_95sceneCode.GDBuyText3Objects1= [];
gdjs.Planet_95sceneCode.GDBuyText3Objects2= [];
gdjs.Planet_95sceneCode.GDBuyText3Objects3= [];
gdjs.Planet_95sceneCode.GDBuyText3Objects4= [];
gdjs.Planet_95sceneCode.GDBuyText3Objects5= [];
gdjs.Planet_95sceneCode.GDBuyText3Objects6= [];
gdjs.Planet_95sceneCode.GDBuyText3Objects7= [];
gdjs.Planet_95sceneCode.GDBuyText4Objects1= [];
gdjs.Planet_95sceneCode.GDBuyText4Objects2= [];
gdjs.Planet_95sceneCode.GDBuyText4Objects3= [];
gdjs.Planet_95sceneCode.GDBuyText4Objects4= [];
gdjs.Planet_95sceneCode.GDBuyText4Objects5= [];
gdjs.Planet_95sceneCode.GDBuyText4Objects6= [];
gdjs.Planet_95sceneCode.GDBuyText4Objects7= [];
gdjs.Planet_95sceneCode.GDBUildObjects1= [];
gdjs.Planet_95sceneCode.GDBUildObjects2= [];
gdjs.Planet_95sceneCode.GDBUildObjects3= [];
gdjs.Planet_95sceneCode.GDBUildObjects4= [];
gdjs.Planet_95sceneCode.GDBUildObjects5= [];
gdjs.Planet_95sceneCode.GDBUildObjects6= [];
gdjs.Planet_95sceneCode.GDBUildObjects7= [];
gdjs.Planet_95sceneCode.GDCloseCraftObjects1= [];
gdjs.Planet_95sceneCode.GDCloseCraftObjects2= [];
gdjs.Planet_95sceneCode.GDCloseCraftObjects3= [];
gdjs.Planet_95sceneCode.GDCloseCraftObjects4= [];
gdjs.Planet_95sceneCode.GDCloseCraftObjects5= [];
gdjs.Planet_95sceneCode.GDCloseCraftObjects6= [];
gdjs.Planet_95sceneCode.GDCloseCraftObjects7= [];
gdjs.Planet_95sceneCode.GDOxygenBarObjects1= [];
gdjs.Planet_95sceneCode.GDOxygenBarObjects2= [];
gdjs.Planet_95sceneCode.GDOxygenBarObjects3= [];
gdjs.Planet_95sceneCode.GDOxygenBarObjects4= [];
gdjs.Planet_95sceneCode.GDOxygenBarObjects5= [];
gdjs.Planet_95sceneCode.GDOxygenBarObjects6= [];
gdjs.Planet_95sceneCode.GDOxygenBarObjects7= [];
gdjs.Planet_95sceneCode.GDMainRocketObjects1= [];
gdjs.Planet_95sceneCode.GDMainRocketObjects2= [];
gdjs.Planet_95sceneCode.GDMainRocketObjects3= [];
gdjs.Planet_95sceneCode.GDMainRocketObjects4= [];
gdjs.Planet_95sceneCode.GDMainRocketObjects5= [];
gdjs.Planet_95sceneCode.GDMainRocketObjects6= [];
gdjs.Planet_95sceneCode.GDMainRocketObjects7= [];
gdjs.Planet_95sceneCode.GDFireObjects1= [];
gdjs.Planet_95sceneCode.GDFireObjects2= [];
gdjs.Planet_95sceneCode.GDFireObjects3= [];
gdjs.Planet_95sceneCode.GDFireObjects4= [];
gdjs.Planet_95sceneCode.GDFireObjects5= [];
gdjs.Planet_95sceneCode.GDFireObjects6= [];
gdjs.Planet_95sceneCode.GDFireObjects7= [];
gdjs.Planet_95sceneCode.GDSmokeObjects1= [];
gdjs.Planet_95sceneCode.GDSmokeObjects2= [];
gdjs.Planet_95sceneCode.GDSmokeObjects3= [];
gdjs.Planet_95sceneCode.GDSmokeObjects4= [];
gdjs.Planet_95sceneCode.GDSmokeObjects5= [];
gdjs.Planet_95sceneCode.GDSmokeObjects6= [];
gdjs.Planet_95sceneCode.GDSmokeObjects7= [];
gdjs.Planet_95sceneCode.GDREsourceObjects1= [];
gdjs.Planet_95sceneCode.GDREsourceObjects2= [];
gdjs.Planet_95sceneCode.GDREsourceObjects3= [];
gdjs.Planet_95sceneCode.GDREsourceObjects4= [];
gdjs.Planet_95sceneCode.GDREsourceObjects5= [];
gdjs.Planet_95sceneCode.GDREsourceObjects6= [];
gdjs.Planet_95sceneCode.GDREsourceObjects7= [];
gdjs.Planet_95sceneCode.GDEnergyObjects1= [];
gdjs.Planet_95sceneCode.GDEnergyObjects2= [];
gdjs.Planet_95sceneCode.GDEnergyObjects3= [];
gdjs.Planet_95sceneCode.GDEnergyObjects4= [];
gdjs.Planet_95sceneCode.GDEnergyObjects5= [];
gdjs.Planet_95sceneCode.GDEnergyObjects6= [];
gdjs.Planet_95sceneCode.GDEnergyObjects7= [];
gdjs.Planet_95sceneCode.GDAstroTextObjects1= [];
gdjs.Planet_95sceneCode.GDAstroTextObjects2= [];
gdjs.Planet_95sceneCode.GDAstroTextObjects3= [];
gdjs.Planet_95sceneCode.GDAstroTextObjects4= [];
gdjs.Planet_95sceneCode.GDAstroTextObjects5= [];
gdjs.Planet_95sceneCode.GDAstroTextObjects6= [];
gdjs.Planet_95sceneCode.GDAstroTextObjects7= [];
gdjs.Planet_95sceneCode.GDEnergyTextObjects1= [];
gdjs.Planet_95sceneCode.GDEnergyTextObjects2= [];
gdjs.Planet_95sceneCode.GDEnergyTextObjects3= [];
gdjs.Planet_95sceneCode.GDEnergyTextObjects4= [];
gdjs.Planet_95sceneCode.GDEnergyTextObjects5= [];
gdjs.Planet_95sceneCode.GDEnergyTextObjects6= [];
gdjs.Planet_95sceneCode.GDEnergyTextObjects7= [];
gdjs.Planet_95sceneCode.GDRepairTextObjects1= [];
gdjs.Planet_95sceneCode.GDRepairTextObjects2= [];
gdjs.Planet_95sceneCode.GDRepairTextObjects3= [];
gdjs.Planet_95sceneCode.GDRepairTextObjects4= [];
gdjs.Planet_95sceneCode.GDRepairTextObjects5= [];
gdjs.Planet_95sceneCode.GDRepairTextObjects6= [];
gdjs.Planet_95sceneCode.GDRepairTextObjects7= [];
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects1= [];
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects2= [];
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects3= [];
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects4= [];
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects5= [];
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects6= [];
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects7= [];
gdjs.Planet_95sceneCode.GDBulletObjects1= [];
gdjs.Planet_95sceneCode.GDBulletObjects2= [];
gdjs.Planet_95sceneCode.GDBulletObjects3= [];
gdjs.Planet_95sceneCode.GDBulletObjects4= [];
gdjs.Planet_95sceneCode.GDBulletObjects5= [];
gdjs.Planet_95sceneCode.GDBulletObjects6= [];
gdjs.Planet_95sceneCode.GDBulletObjects7= [];
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects1= [];
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects2= [];
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects3= [];
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects4= [];
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects5= [];
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects6= [];
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects7= [];


gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Planet_95sceneCode.GDPlayerObjects1});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDShip_95959595AccessObjects1Objects = Hashtable.newFrom({"Ship_Access": gdjs.Planet_95sceneCode.GDShip_9595AccessObjects1});
gdjs.Planet_95sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Space_scene");
}
}

}


};gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarHObjects4ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDDrillHObjects4ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDWindmillHObjects4ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDShieldHObjects4Objects = Hashtable.newFrom({"SolarH": gdjs.Planet_95sceneCode.GDSolarHObjects4, "DrillH": gdjs.Planet_95sceneCode.GDDrillHObjects4, "WindmillH": gdjs.Planet_95sceneCode.GDWindmillHObjects4, "ShieldH": gdjs.Planet_95sceneCode.GDShieldHObjects4});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects4Objects = Hashtable.newFrom({"Inventory": gdjs.Planet_95sceneCode.GDInventoryObjects4});
gdjs.Planet_95sceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDDrillHObjects3, gdjs.Planet_95sceneCode.GDDrillHObjects4);

gdjs.copyArray(runtimeScene.getObjects("Inventory"), gdjs.Planet_95sceneCode.GDInventoryObjects4);
gdjs.copyArray(gdjs.Planet_95sceneCode.GDShieldHObjects3, gdjs.Planet_95sceneCode.GDShieldHObjects4);

gdjs.copyArray(gdjs.Planet_95sceneCode.GDSolarHObjects3, gdjs.Planet_95sceneCode.GDSolarHObjects4);

gdjs.copyArray(gdjs.Planet_95sceneCode.GDWindmillHObjects3, gdjs.Planet_95sceneCode.GDWindmillHObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDSolarHObjects4.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDSolarHObjects4[i].getBehavior("Draggable").wasJustDropped() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDSolarHObjects4[k] = gdjs.Planet_95sceneCode.GDSolarHObjects4[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDSolarHObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDDrillHObjects4.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDDrillHObjects4[i].getBehavior("Draggable").wasJustDropped() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDDrillHObjects4[k] = gdjs.Planet_95sceneCode.GDDrillHObjects4[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDDrillHObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDWindmillHObjects4.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDWindmillHObjects4[i].getBehavior("Draggable").wasJustDropped() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDWindmillHObjects4[k] = gdjs.Planet_95sceneCode.GDWindmillHObjects4[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDWindmillHObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDShieldHObjects4.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDShieldHObjects4[i].getBehavior("Draggable").wasJustDropped() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDShieldHObjects4[k] = gdjs.Planet_95sceneCode.GDShieldHObjects4[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDShieldHObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarHObjects4ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDDrillHObjects4ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDWindmillHObjects4ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDShieldHObjects4Objects, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects4Objects, true, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDDrillHObjects4 */
/* Reuse gdjs.Planet_95sceneCode.GDShieldHObjects4 */
/* Reuse gdjs.Planet_95sceneCode.GDSolarHObjects4 */
/* Reuse gdjs.Planet_95sceneCode.GDWindmillHObjects4 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects4[i].returnVariable(gdjs.Planet_95sceneCode.GDSolarHObjects4[i].getVariables().get("Spawned")).setBoolean(true);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects4[i].returnVariable(gdjs.Planet_95sceneCode.GDDrillHObjects4[i].getVariables().get("Spawned")).setBoolean(true);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects4[i].returnVariable(gdjs.Planet_95sceneCode.GDWindmillHObjects4[i].getVariables().get("Spawned")).setBoolean(true);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects4[i].returnVariable(gdjs.Planet_95sceneCode.GDShieldHObjects4[i].getVariables().get("Spawned")).setBoolean(true);
}
}
}

}


};gdjs.Planet_95sceneCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.Planet_95sceneCode.GDDrillHObjects2 */
/* Reuse gdjs.Planet_95sceneCode.GDShieldHObjects2 */
/* Reuse gdjs.Planet_95sceneCode.GDSolarHObjects2 */
/* Reuse gdjs.Planet_95sceneCode.GDWindmillHObjects2 */

gdjs.Planet_95sceneCode.forEachTotalCount3 = 0;
gdjs.Planet_95sceneCode.forEachObjects3.length = 0;
gdjs.Planet_95sceneCode.forEachCount0_3 = gdjs.Planet_95sceneCode.GDSolarHObjects2.length;
gdjs.Planet_95sceneCode.forEachTotalCount3 += gdjs.Planet_95sceneCode.forEachCount0_3;
gdjs.Planet_95sceneCode.forEachObjects3.push.apply(gdjs.Planet_95sceneCode.forEachObjects3,gdjs.Planet_95sceneCode.GDSolarHObjects2);
gdjs.Planet_95sceneCode.forEachCount1_3 = gdjs.Planet_95sceneCode.GDDrillHObjects2.length;
gdjs.Planet_95sceneCode.forEachTotalCount3 += gdjs.Planet_95sceneCode.forEachCount1_3;
gdjs.Planet_95sceneCode.forEachObjects3.push.apply(gdjs.Planet_95sceneCode.forEachObjects3,gdjs.Planet_95sceneCode.GDDrillHObjects2);
gdjs.Planet_95sceneCode.forEachCount2_3 = gdjs.Planet_95sceneCode.GDWindmillHObjects2.length;
gdjs.Planet_95sceneCode.forEachTotalCount3 += gdjs.Planet_95sceneCode.forEachCount2_3;
gdjs.Planet_95sceneCode.forEachObjects3.push.apply(gdjs.Planet_95sceneCode.forEachObjects3,gdjs.Planet_95sceneCode.GDWindmillHObjects2);
gdjs.Planet_95sceneCode.forEachCount3_3 = gdjs.Planet_95sceneCode.GDShieldHObjects2.length;
gdjs.Planet_95sceneCode.forEachTotalCount3 += gdjs.Planet_95sceneCode.forEachCount3_3;
gdjs.Planet_95sceneCode.forEachObjects3.push.apply(gdjs.Planet_95sceneCode.forEachObjects3,gdjs.Planet_95sceneCode.GDShieldHObjects2);
for (gdjs.Planet_95sceneCode.forEachIndex3 = 0;gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachTotalCount3;++gdjs.Planet_95sceneCode.forEachIndex3) {
gdjs.Planet_95sceneCode.GDDrillHObjects3.length = 0;

gdjs.Planet_95sceneCode.GDShieldHObjects3.length = 0;

gdjs.Planet_95sceneCode.GDSolarHObjects3.length = 0;

gdjs.Planet_95sceneCode.GDWindmillHObjects3.length = 0;


if (gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachCount0_3) {
    gdjs.Planet_95sceneCode.GDSolarHObjects3.push(gdjs.Planet_95sceneCode.forEachObjects3[gdjs.Planet_95sceneCode.forEachIndex3]);
}
else if (gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachCount0_3+gdjs.Planet_95sceneCode.forEachCount1_3) {
    gdjs.Planet_95sceneCode.GDDrillHObjects3.push(gdjs.Planet_95sceneCode.forEachObjects3[gdjs.Planet_95sceneCode.forEachIndex3]);
}
else if (gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachCount0_3+gdjs.Planet_95sceneCode.forEachCount1_3+gdjs.Planet_95sceneCode.forEachCount2_3) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects3.push(gdjs.Planet_95sceneCode.forEachObjects3[gdjs.Planet_95sceneCode.forEachIndex3]);
}
else if (gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachCount0_3+gdjs.Planet_95sceneCode.forEachCount1_3+gdjs.Planet_95sceneCode.forEachCount2_3+gdjs.Planet_95sceneCode.forEachCount3_3) {
    gdjs.Planet_95sceneCode.GDShieldHObjects3.push(gdjs.Planet_95sceneCode.forEachObjects3[gdjs.Planet_95sceneCode.forEachIndex3]);
}
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Planet_95sceneCode.eventsList1(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarHObjects6Objects = Hashtable.newFrom({"SolarH": gdjs.Planet_95sceneCode.GDSolarHObjects6});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDDrillHObjects6Objects = Hashtable.newFrom({"DrillH": gdjs.Planet_95sceneCode.GDDrillHObjects6});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDWindmillHObjects6Objects = Hashtable.newFrom({"WindmillH": gdjs.Planet_95sceneCode.GDWindmillHObjects6});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDShieldHObjects6Objects = Hashtable.newFrom({"ShieldH": gdjs.Planet_95sceneCode.GDShieldHObjects6});
gdjs.Planet_95sceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDInventoryObjects4, gdjs.Planet_95sceneCode.GDInventoryObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDInventoryObjects6.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDInventoryObjects6[i].getVariableString(gdjs.Planet_95sceneCode.GDInventoryObjects6[i].getVariables().getFromIndex(0)) == "solar" ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDInventoryObjects6[k] = gdjs.Planet_95sceneCode.GDInventoryObjects6[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDInventoryObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDInventoryObjects6 */
gdjs.Planet_95sceneCode.GDSolarHObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarHObjects6Objects, (( gdjs.Planet_95sceneCode.GDInventoryObjects6.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDInventoryObjects6[0].getPointX("")), (( gdjs.Planet_95sceneCode.GDInventoryObjects6.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDInventoryObjects6[0].getPointY("")), "BUild_Mode");
}
}

}


{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDInventoryObjects4, gdjs.Planet_95sceneCode.GDInventoryObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDInventoryObjects6.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDInventoryObjects6[i].getVariableString(gdjs.Planet_95sceneCode.GDInventoryObjects6[i].getVariables().getFromIndex(0)) == "drill" ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDInventoryObjects6[k] = gdjs.Planet_95sceneCode.GDInventoryObjects6[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDInventoryObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDInventoryObjects6 */
gdjs.Planet_95sceneCode.GDDrillHObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDDrillHObjects6Objects, (( gdjs.Planet_95sceneCode.GDInventoryObjects6.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDInventoryObjects6[0].getPointX("")), (( gdjs.Planet_95sceneCode.GDInventoryObjects6.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDInventoryObjects6[0].getPointY("")), "BUild_Mode");
}
}

}


{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDInventoryObjects4, gdjs.Planet_95sceneCode.GDInventoryObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDInventoryObjects6.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDInventoryObjects6[i].getVariableString(gdjs.Planet_95sceneCode.GDInventoryObjects6[i].getVariables().getFromIndex(0)) == "windmill" ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDInventoryObjects6[k] = gdjs.Planet_95sceneCode.GDInventoryObjects6[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDInventoryObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDInventoryObjects6 */
gdjs.Planet_95sceneCode.GDWindmillHObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDWindmillHObjects6Objects, (( gdjs.Planet_95sceneCode.GDInventoryObjects6.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDInventoryObjects6[0].getPointX("")), (( gdjs.Planet_95sceneCode.GDInventoryObjects6.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDInventoryObjects6[0].getPointY("")), "BUild_Mode");
}
}

}


{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDInventoryObjects4, gdjs.Planet_95sceneCode.GDInventoryObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDInventoryObjects6.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDInventoryObjects6[i].getVariableString(gdjs.Planet_95sceneCode.GDInventoryObjects6[i].getVariables().getFromIndex(0)) == "shield" ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDInventoryObjects6[k] = gdjs.Planet_95sceneCode.GDInventoryObjects6[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDInventoryObjects6.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDInventoryObjects6 */
gdjs.Planet_95sceneCode.GDShieldHObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDShieldHObjects6Objects, (( gdjs.Planet_95sceneCode.GDInventoryObjects6.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDInventoryObjects6[0].getPointX("")), (( gdjs.Planet_95sceneCode.GDInventoryObjects6.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDInventoryObjects6[0].getPointY("")), "BUild_Mode");
}
}

}


};gdjs.Planet_95sceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDInventoryObjects3, gdjs.Planet_95sceneCode.GDInventoryObjects4);


const repeatCount5 = ((gdjs.Planet_95sceneCode.GDInventoryObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Planet_95sceneCode.GDInventoryObjects4[0].getVariables()).getFromIndex(1).getAsNumber();
for (let repeatIndex5 = 0;repeatIndex5 < repeatCount5;++repeatIndex5) {

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18958508);
}
if (isConditionTrue_0)
{

{ //Subevents: 
gdjs.Planet_95sceneCode.eventsList3(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Planet_95sceneCode.GDPlayerObjects2});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDBUildObjects2Objects = Hashtable.newFrom({"BUild": gdjs.Planet_95sceneCode.GDBUildObjects2});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarObjects4Objects = Hashtable.newFrom({"Solar": gdjs.Planet_95sceneCode.GDSolarObjects4});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDDrillObjects4Objects = Hashtable.newFrom({"Drill": gdjs.Planet_95sceneCode.GDDrillObjects4});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDWindmillObjects4Objects = Hashtable.newFrom({"Windmill": gdjs.Planet_95sceneCode.GDWindmillObjects4});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDShieldObjects4Objects = Hashtable.newFrom({"Shield": gdjs.Planet_95sceneCode.GDShieldObjects4});
gdjs.Planet_95sceneCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDSolarHObjects3, gdjs.Planet_95sceneCode.GDSolarHObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDSolarHObjects4.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDSolarHObjects4[i].getVariableBoolean(gdjs.Planet_95sceneCode.GDSolarHObjects4[i].getVariables().getFromIndex(2), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDSolarHObjects4[k] = gdjs.Planet_95sceneCode.GDSolarHObjects4[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDSolarHObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18966516);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Planet_95sceneCode.GDDrillHObjects3, gdjs.Planet_95sceneCode.GDDrillHObjects4);

gdjs.copyArray(gdjs.Planet_95sceneCode.GDShieldHObjects3, gdjs.Planet_95sceneCode.GDShieldHObjects4);

/* Reuse gdjs.Planet_95sceneCode.GDSolarHObjects4 */
gdjs.copyArray(gdjs.Planet_95sceneCode.GDWindmillHObjects3, gdjs.Planet_95sceneCode.GDWindmillHObjects4);

gdjs.Planet_95sceneCode.GDSolarObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarObjects4Objects, (( gdjs.Planet_95sceneCode.GDSolarHObjects4.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDSolarHObjects4[0].getCenterXInScene()), (( gdjs.Planet_95sceneCode.GDSolarHObjects4.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDSolarHObjects4[0].getCenterYInScene()), "");
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects4[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarObjects4[i].resetTimer("Cooldown");
}
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarObjects4[i].setLayer("");
}
}
}

}


{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDDrillHObjects3, gdjs.Planet_95sceneCode.GDDrillHObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDDrillHObjects4.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDDrillHObjects4[i].getVariableBoolean(gdjs.Planet_95sceneCode.GDDrillHObjects4[i].getVariables().getFromIndex(2), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDDrillHObjects4[k] = gdjs.Planet_95sceneCode.GDDrillHObjects4[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDDrillHObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18967644);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDDrillHObjects4 */
gdjs.copyArray(gdjs.Planet_95sceneCode.GDShieldHObjects3, gdjs.Planet_95sceneCode.GDShieldHObjects4);

gdjs.copyArray(gdjs.Planet_95sceneCode.GDSolarHObjects3, gdjs.Planet_95sceneCode.GDSolarHObjects4);

gdjs.copyArray(gdjs.Planet_95sceneCode.GDWindmillHObjects3, gdjs.Planet_95sceneCode.GDWindmillHObjects4);

gdjs.Planet_95sceneCode.GDDrillObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDDrillObjects4Objects, (( gdjs.Planet_95sceneCode.GDDrillHObjects4.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDDrillHObjects4[0].getPointX("")), (( gdjs.Planet_95sceneCode.GDDrillHObjects4.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDDrillHObjects4[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects4[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillObjects4[i].resetTimer("Cooldown");
}
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillObjects4[i].setLayer("");
}
}
}

}


{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDWindmillHObjects3, gdjs.Planet_95sceneCode.GDWindmillHObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDWindmillHObjects4.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDWindmillHObjects4[i].getVariableBoolean(gdjs.Planet_95sceneCode.GDWindmillHObjects4[i].getVariables().getFromIndex(2), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDWindmillHObjects4[k] = gdjs.Planet_95sceneCode.GDWindmillHObjects4[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDWindmillHObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18968852);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Planet_95sceneCode.GDDrillHObjects3, gdjs.Planet_95sceneCode.GDDrillHObjects4);

gdjs.copyArray(gdjs.Planet_95sceneCode.GDShieldHObjects3, gdjs.Planet_95sceneCode.GDShieldHObjects4);

gdjs.copyArray(gdjs.Planet_95sceneCode.GDSolarHObjects3, gdjs.Planet_95sceneCode.GDSolarHObjects4);

/* Reuse gdjs.Planet_95sceneCode.GDWindmillHObjects4 */
gdjs.Planet_95sceneCode.GDWindmillObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDWindmillObjects4Objects, (( gdjs.Planet_95sceneCode.GDWindmillHObjects4.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDWindmillHObjects4[0].getPointX("")), (( gdjs.Planet_95sceneCode.GDWindmillHObjects4.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDWindmillHObjects4[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects4[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillObjects4[i].resetTimer("Cooldown");
}
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillObjects4[i].setLayer("");
}
}
}

}


{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDShieldHObjects3, gdjs.Planet_95sceneCode.GDShieldHObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDShieldHObjects4.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDShieldHObjects4[i].getVariableBoolean(gdjs.Planet_95sceneCode.GDShieldHObjects4[i].getVariables().getFromIndex(2), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDShieldHObjects4[k] = gdjs.Planet_95sceneCode.GDShieldHObjects4[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDShieldHObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18969996);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Planet_95sceneCode.GDDrillHObjects3, gdjs.Planet_95sceneCode.GDDrillHObjects4);

/* Reuse gdjs.Planet_95sceneCode.GDShieldHObjects4 */
gdjs.copyArray(gdjs.Planet_95sceneCode.GDSolarHObjects3, gdjs.Planet_95sceneCode.GDSolarHObjects4);

gdjs.copyArray(gdjs.Planet_95sceneCode.GDWindmillHObjects3, gdjs.Planet_95sceneCode.GDWindmillHObjects4);

gdjs.Planet_95sceneCode.GDShieldObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDShieldObjects4Objects, (( gdjs.Planet_95sceneCode.GDShieldHObjects4.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDShieldHObjects4[0].getPointX("")), (( gdjs.Planet_95sceneCode.GDShieldHObjects4.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDShieldHObjects4[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects4[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldObjects4[i].resetTimer("Cooldown");
}
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldObjects4.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldObjects4[i].setLayer("");
}
}
}

}


};gdjs.Planet_95sceneCode.eventsList6 = function(runtimeScene) {

{

/* Reuse gdjs.Planet_95sceneCode.GDDrillHObjects2 */
/* Reuse gdjs.Planet_95sceneCode.GDShieldHObjects2 */
/* Reuse gdjs.Planet_95sceneCode.GDSolarHObjects2 */
/* Reuse gdjs.Planet_95sceneCode.GDWindmillHObjects2 */

gdjs.Planet_95sceneCode.forEachTotalCount3 = 0;
gdjs.Planet_95sceneCode.forEachObjects3.length = 0;
gdjs.Planet_95sceneCode.forEachCount0_3 = gdjs.Planet_95sceneCode.GDSolarHObjects2.length;
gdjs.Planet_95sceneCode.forEachTotalCount3 += gdjs.Planet_95sceneCode.forEachCount0_3;
gdjs.Planet_95sceneCode.forEachObjects3.push.apply(gdjs.Planet_95sceneCode.forEachObjects3,gdjs.Planet_95sceneCode.GDSolarHObjects2);
gdjs.Planet_95sceneCode.forEachCount1_3 = gdjs.Planet_95sceneCode.GDDrillHObjects2.length;
gdjs.Planet_95sceneCode.forEachTotalCount3 += gdjs.Planet_95sceneCode.forEachCount1_3;
gdjs.Planet_95sceneCode.forEachObjects3.push.apply(gdjs.Planet_95sceneCode.forEachObjects3,gdjs.Planet_95sceneCode.GDDrillHObjects2);
gdjs.Planet_95sceneCode.forEachCount2_3 = gdjs.Planet_95sceneCode.GDWindmillHObjects2.length;
gdjs.Planet_95sceneCode.forEachTotalCount3 += gdjs.Planet_95sceneCode.forEachCount2_3;
gdjs.Planet_95sceneCode.forEachObjects3.push.apply(gdjs.Planet_95sceneCode.forEachObjects3,gdjs.Planet_95sceneCode.GDWindmillHObjects2);
gdjs.Planet_95sceneCode.forEachCount3_3 = gdjs.Planet_95sceneCode.GDShieldHObjects2.length;
gdjs.Planet_95sceneCode.forEachTotalCount3 += gdjs.Planet_95sceneCode.forEachCount3_3;
gdjs.Planet_95sceneCode.forEachObjects3.push.apply(gdjs.Planet_95sceneCode.forEachObjects3,gdjs.Planet_95sceneCode.GDShieldHObjects2);
for (gdjs.Planet_95sceneCode.forEachIndex3 = 0;gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachTotalCount3;++gdjs.Planet_95sceneCode.forEachIndex3) {
gdjs.Planet_95sceneCode.GDDrillHObjects3.length = 0;

gdjs.Planet_95sceneCode.GDShieldHObjects3.length = 0;

gdjs.Planet_95sceneCode.GDSolarHObjects3.length = 0;

gdjs.Planet_95sceneCode.GDWindmillHObjects3.length = 0;


if (gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachCount0_3) {
    gdjs.Planet_95sceneCode.GDSolarHObjects3.push(gdjs.Planet_95sceneCode.forEachObjects3[gdjs.Planet_95sceneCode.forEachIndex3]);
}
else if (gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachCount0_3+gdjs.Planet_95sceneCode.forEachCount1_3) {
    gdjs.Planet_95sceneCode.GDDrillHObjects3.push(gdjs.Planet_95sceneCode.forEachObjects3[gdjs.Planet_95sceneCode.forEachIndex3]);
}
else if (gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachCount0_3+gdjs.Planet_95sceneCode.forEachCount1_3+gdjs.Planet_95sceneCode.forEachCount2_3) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects3.push(gdjs.Planet_95sceneCode.forEachObjects3[gdjs.Planet_95sceneCode.forEachIndex3]);
}
else if (gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.forEachCount0_3+gdjs.Planet_95sceneCode.forEachCount1_3+gdjs.Planet_95sceneCode.forEachCount2_3+gdjs.Planet_95sceneCode.forEachCount3_3) {
    gdjs.Planet_95sceneCode.GDShieldHObjects3.push(gdjs.Planet_95sceneCode.forEachObjects3[gdjs.Planet_95sceneCode.forEachIndex3]);
}
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Planet_95sceneCode.eventsList5(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Planet_95sceneCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Inventory"), gdjs.Planet_95sceneCode.GDInventoryObjects2);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDInventoryObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDInventoryObjects2[i].returnVariable(gdjs.Planet_95sceneCode.GDInventoryObjects2[i].getVariables().getFromIndex(2)).setBoolean(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CloseCraft"), gdjs.Planet_95sceneCode.GDCloseCraftObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDCloseCraftObjects2.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDCloseCraftObjects2[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDCloseCraftObjects2[k] = gdjs.Planet_95sceneCode.GDCloseCraftObjects2[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDCloseCraftObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setBoolean(false);
}
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DrillH"), gdjs.Planet_95sceneCode.GDDrillHObjects2);
gdjs.copyArray(runtimeScene.getObjects("ShieldH"), gdjs.Planet_95sceneCode.GDShieldHObjects2);
gdjs.copyArray(runtimeScene.getObjects("SolarH"), gdjs.Planet_95sceneCode.GDSolarHObjects2);
gdjs.copyArray(runtimeScene.getObjects("WindmillH"), gdjs.Planet_95sceneCode.GDWindmillHObjects2);
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 0);
}
{gdjs.evtTools.camera.showLayer(runtimeScene, "BUild_Mode");
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects2[i].activateBehavior("Draggable", true);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects2[i].activateBehavior("Draggable", true);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects2[i].activateBehavior("Draggable", true);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects2[i].activateBehavior("Draggable", true);
}
}

{ //Subevents
gdjs.Planet_95sceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Inventory"), gdjs.Planet_95sceneCode.GDInventoryObjects2);

for (gdjs.Planet_95sceneCode.forEachIndex3 = 0;gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.GDInventoryObjects2.length;++gdjs.Planet_95sceneCode.forEachIndex3) {
gdjs.Planet_95sceneCode.GDInventoryObjects3.length = 0;


gdjs.Planet_95sceneCode.forEachTemporary3 = gdjs.Planet_95sceneCode.GDInventoryObjects2[gdjs.Planet_95sceneCode.forEachIndex3];
gdjs.Planet_95sceneCode.GDInventoryObjects3.push(gdjs.Planet_95sceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDInventoryObjects3.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDInventoryObjects3[i].getVariableBoolean(gdjs.Planet_95sceneCode.GDInventoryObjects3[i].getVariables().getFromIndex(2), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDInventoryObjects3[k] = gdjs.Planet_95sceneCode.GDInventoryObjects3[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDInventoryObjects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDInventoryObjects3.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDInventoryObjects3[i].returnVariable(gdjs.Planet_95sceneCode.GDInventoryObjects3[i].getVariables().getFromIndex(2)).setBoolean(false);
}
}

{ //Subevents: 
gdjs.Planet_95sceneCode.eventsList4(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BUild"), gdjs.Planet_95sceneCode.GDBUildObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDPlayerObjects2Objects, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDBUildObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13367180);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setBoolean(true);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DrillH"), gdjs.Planet_95sceneCode.GDDrillHObjects2);
gdjs.copyArray(runtimeScene.getObjects("ShieldH"), gdjs.Planet_95sceneCode.GDShieldHObjects2);
gdjs.copyArray(runtimeScene.getObjects("SolarH"), gdjs.Planet_95sceneCode.GDSolarHObjects2);
gdjs.copyArray(runtimeScene.getObjects("WindmillH"), gdjs.Planet_95sceneCode.GDWindmillHObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "BUild_Mode");
}
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 1);
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects2[i].activateBehavior("Draggable", false);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects2[i].activateBehavior("Draggable", false);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects2[i].activateBehavior("Draggable", false);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects2[i].activateBehavior("Draggable", false);
}
}

{ //Subevents
gdjs.Planet_95sceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DrillH"), gdjs.Planet_95sceneCode.GDDrillHObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShieldH"), gdjs.Planet_95sceneCode.GDShieldHObjects1);
gdjs.copyArray(runtimeScene.getObjects("SolarH"), gdjs.Planet_95sceneCode.GDSolarHObjects1);
gdjs.copyArray(runtimeScene.getObjects("WindmillH"), gdjs.Planet_95sceneCode.GDWindmillHObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDSolarHObjects1.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDSolarHObjects1[i].getVariableBoolean(gdjs.Planet_95sceneCode.GDSolarHObjects1[i].getVariables().get("Spawned"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDSolarHObjects1[k] = gdjs.Planet_95sceneCode.GDSolarHObjects1[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDSolarHObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDDrillHObjects1.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDDrillHObjects1[i].getVariableBoolean(gdjs.Planet_95sceneCode.GDDrillHObjects1[i].getVariables().get("Spawned"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDDrillHObjects1[k] = gdjs.Planet_95sceneCode.GDDrillHObjects1[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDDrillHObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDWindmillHObjects1.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDWindmillHObjects1[i].getVariableBoolean(gdjs.Planet_95sceneCode.GDWindmillHObjects1[i].getVariables().get("Spawned"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDWindmillHObjects1[k] = gdjs.Planet_95sceneCode.GDWindmillHObjects1[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDWindmillHObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDShieldHObjects1.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDShieldHObjects1[i].getVariableBoolean(gdjs.Planet_95sceneCode.GDShieldHObjects1[i].getVariables().get("Spawned"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDShieldHObjects1[k] = gdjs.Planet_95sceneCode.GDShieldHObjects1[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDShieldHObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDDrillHObjects1 */
/* Reuse gdjs.Planet_95sceneCode.GDShieldHObjects1 */
/* Reuse gdjs.Planet_95sceneCode.GDSolarHObjects1 */
/* Reuse gdjs.Planet_95sceneCode.GDWindmillHObjects1 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects1[i].setColor("92;190;204");
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects1[i].setColor("92;190;204");
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects1[i].setColor("92;190;204");
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects1[i].setColor("92;190;204");
}
}
}

}


};gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Planet_95sceneCode.GDPlayerObjects2});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDCraftObjects2Objects = Hashtable.newFrom({"Craft": gdjs.Planet_95sceneCode.GDCraftObjects2});
gdjs.Planet_95sceneCode.eventsList8 = function(runtimeScene) {

{

/* Reuse gdjs.Planet_95sceneCode.GDBuyObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Inventory"), gdjs.Planet_95sceneCode.GDInventoryObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDInventoryObjects3.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDInventoryObjects3[i].getVariableString(gdjs.Planet_95sceneCode.GDInventoryObjects3[i].getVariables().getFromIndex(0)) == ((gdjs.Planet_95sceneCode.GDBuyObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Planet_95sceneCode.GDBuyObjects3[0].getVariables()).getFromIndex(1).getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDInventoryObjects3[k] = gdjs.Planet_95sceneCode.GDInventoryObjects3[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDInventoryObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDInventoryObjects3 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDInventoryObjects3.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDInventoryObjects3[i].returnVariable(gdjs.Planet_95sceneCode.GDInventoryObjects3[i].getVariables().getFromIndex(1)).add(1);
}
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDInventoryObjects3.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDInventoryObjects3[i].returnVariable(gdjs.Planet_95sceneCode.GDInventoryObjects3[i].getVariables().getFromIndex(2)).setBoolean(true);
}
}
}

}


};gdjs.Planet_95sceneCode.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.Planet_95sceneCode.GDBuyObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDBuyObjects3.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDBuyObjects3[i].getVariableNumber(gdjs.Planet_95sceneCode.GDBuyObjects3[i].getVariables().getFromIndex(0)) < runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDBuyObjects3[k] = gdjs.Planet_95sceneCode.GDBuyObjects3[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDBuyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDBuyObjects3 */
{runtimeScene.getGame().getVariables().getFromIndex(6).sub(((gdjs.Planet_95sceneCode.GDBuyObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Planet_95sceneCode.GDBuyObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}

{ //Subevents
gdjs.Planet_95sceneCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.Planet_95sceneCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Buy"), gdjs.Planet_95sceneCode.GDBuyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDBuyObjects3.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDBuyObjects3[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDBuyObjects3[k] = gdjs.Planet_95sceneCode.GDBuyObjects3[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDBuyObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Planet_95sceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CloseBuy"), gdjs.Planet_95sceneCode.GDCloseBuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDCloseBuyObjects2.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDCloseBuyObjects2[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDCloseBuyObjects2[k] = gdjs.Planet_95sceneCode.GDCloseBuyObjects2[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDCloseBuyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDCloseCraftObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(5).setBoolean(false);
}
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 1);
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDCloseCraftObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDCloseCraftObjects2[i].hide(false);
}
}
}

}


};gdjs.Planet_95sceneCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Craft"), gdjs.Planet_95sceneCode.GDCraftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDPlayerObjects2Objects, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDCraftObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).setBoolean(true);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CloseCraft"), gdjs.Planet_95sceneCode.GDCloseCraftObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Craft_mode");
}
{gdjs.evtTools.camera.showLayer(runtimeScene, "BUild_Mode");
}
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 0);
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDCloseCraftObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDCloseCraftObjects2[i].hide();
}
}

{ //Subevents
gdjs.Planet_95sceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Craft_mode");
}
}

}


};gdjs.Planet_95sceneCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Drill"), gdjs.Planet_95sceneCode.GDDrillObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDDrillObjects2.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDDrillObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Cooldown") >= gdjs.Planet_95sceneCode.GDDrillObjects2[i].getVariables().getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDDrillObjects2[k] = gdjs.Planet_95sceneCode.GDDrillObjects2[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDDrillObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDDrillObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillObjects2[i].resetTimer("Cooldown");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Solar"), gdjs.Planet_95sceneCode.GDSolarObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDSolarObjects2.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDSolarObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Cooldown") >= gdjs.Planet_95sceneCode.GDSolarObjects2[i].getVariables().getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDSolarObjects2[k] = gdjs.Planet_95sceneCode.GDSolarObjects2[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDSolarObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDSolarObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarObjects2[i].resetTimer("Cooldown");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield"), gdjs.Planet_95sceneCode.GDShieldObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDShieldObjects2.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDShieldObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Cooldown") >= gdjs.Planet_95sceneCode.GDShieldObjects2[i].getVariables().getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDShieldObjects2[k] = gdjs.Planet_95sceneCode.GDShieldObjects2[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDShieldObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDShieldObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldObjects2[i].resetTimer("Cooldown");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield"), gdjs.Planet_95sceneCode.GDShieldObjects1);
gdjs.copyArray(runtimeScene.getObjects("Windmill"), gdjs.Planet_95sceneCode.GDWindmillObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDWindmillObjects1.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDWindmillObjects1[i].getTimerElapsedTimeInSecondsOrNaN("Cooldown") >= ((gdjs.Planet_95sceneCode.GDShieldObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Planet_95sceneCode.GDShieldObjects1[0].getVariables()).getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDWindmillObjects1[k] = gdjs.Planet_95sceneCode.GDWindmillObjects1[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDWindmillObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDWindmillObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillObjects1[i].resetTimer("Cooldown");
}
}
}

}


};gdjs.Planet_95sceneCode.eventsList13 = function(runtimeScene) {

};gdjs.Planet_95sceneCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Rocks"), gdjs.Planet_95sceneCode.GDRocksObjects2);

for (gdjs.Planet_95sceneCode.forEachIndex3 = 0;gdjs.Planet_95sceneCode.forEachIndex3 < gdjs.Planet_95sceneCode.GDRocksObjects2.length;++gdjs.Planet_95sceneCode.forEachIndex3) {
gdjs.Planet_95sceneCode.GDRocksObjects3.length = 0;


gdjs.Planet_95sceneCode.forEachTemporary3 = gdjs.Planet_95sceneCode.GDRocksObjects2[gdjs.Planet_95sceneCode.forEachIndex3];
gdjs.Planet_95sceneCode.GDRocksObjects3.push(gdjs.Planet_95sceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDRocksObjects3.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDRocksObjects3[i].returnVariable(gdjs.Planet_95sceneCode.GDRocksObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(0, 7));
}
}
}
}

}


};gdjs.Planet_95sceneCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Planet_95sceneCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Rocks"), gdjs.Planet_95sceneCode.GDRocksObjects2);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDRocksObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDRocksObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.Planet_95sceneCode.GDRocksObjects2[i].getVariables().getFromIndex(0).getAsNumber());
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDPlayerObjects2[k] = gdjs.Planet_95sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Planet_95sceneCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDPlayerObjects2[k] = gdjs.Planet_95sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Planet_95sceneCode.GDPlayerObjects2[i].getX() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDPlayerObjects2[k] = gdjs.Planet_95sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDPlayerObjects2[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Planet_95sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Planet_95sceneCode.GDPlayerObjects1[i].getX() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0)) ) {
        isConditionTrue_0 = true;
        gdjs.Planet_95sceneCode.GDPlayerObjects1[k] = gdjs.Planet_95sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Planet_95sceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


};gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryTextObjects5Objects = Hashtable.newFrom({"InventoryText": gdjs.Planet_95sceneCode.GDInventoryTextObjects5});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects5Objects = Hashtable.newFrom({"Inventory": gdjs.Planet_95sceneCode.GDInventoryObjects5});
gdjs.Planet_95sceneCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Planet_95sceneCode.GDInventoryObjects4, gdjs.Planet_95sceneCode.GDInventoryObjects5);

gdjs.copyArray(gdjs.Planet_95sceneCode.GDInventoryTextObjects2, gdjs.Planet_95sceneCode.GDInventoryTextObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryTextObjects5Objects, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDInventoryObjects5 */
/* Reuse gdjs.Planet_95sceneCode.GDInventoryTextObjects5 */
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Planet_95sceneCode.GDInventoryObjects5.length !== 0 ? gdjs.Planet_95sceneCode.GDInventoryObjects5[0] : null), (gdjs.Planet_95sceneCode.GDInventoryTextObjects5.length !== 0 ? gdjs.Planet_95sceneCode.GDInventoryTextObjects5[0] : null));
}
}

}


};gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects3Objects = Hashtable.newFrom({"Inventory": gdjs.Planet_95sceneCode.GDInventoryObjects3});
gdjs.Planet_95sceneCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Inventory"), gdjs.Planet_95sceneCode.GDInventoryObjects3);

for (gdjs.Planet_95sceneCode.forEachIndex4 = 0;gdjs.Planet_95sceneCode.forEachIndex4 < gdjs.Planet_95sceneCode.GDInventoryObjects3.length;++gdjs.Planet_95sceneCode.forEachIndex4) {
gdjs.Planet_95sceneCode.GDInventoryObjects4.length = 0;


gdjs.Planet_95sceneCode.forEachTemporary4 = gdjs.Planet_95sceneCode.GDInventoryObjects3[gdjs.Planet_95sceneCode.forEachIndex4];
gdjs.Planet_95sceneCode.GDInventoryObjects4.push(gdjs.Planet_95sceneCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Planet_95sceneCode.eventsList16(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Inventory"), gdjs.Planet_95sceneCode.GDInventoryObjects3);
gdjs.copyArray(gdjs.Planet_95sceneCode.GDInventoryTextObjects2, gdjs.Planet_95sceneCode.GDInventoryTextObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects3Objects, (gdjs.Planet_95sceneCode.GDInventoryTextObjects3.length !== 0 ? gdjs.Planet_95sceneCode.GDInventoryTextObjects3[0] : null), null);
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDInventoryObjects3 */
/* Reuse gdjs.Planet_95sceneCode.GDInventoryTextObjects3 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDInventoryTextObjects3.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDInventoryTextObjects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(((gdjs.Planet_95sceneCode.GDInventoryObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Planet_95sceneCode.GDInventoryObjects3[0].getVariables()).getFromIndex(1).getAsNumber()));
}
}
}

}


};gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDDrillHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDWindmillHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDShieldHObjects1Objects = Hashtable.newFrom({"SolarH": gdjs.Planet_95sceneCode.GDSolarHObjects1, "DrillH": gdjs.Planet_95sceneCode.GDDrillHObjects1, "WindmillH": gdjs.Planet_95sceneCode.GDWindmillHObjects1, "ShieldH": gdjs.Planet_95sceneCode.GDShieldHObjects1});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects1Objects = Hashtable.newFrom({"Inventory": gdjs.Planet_95sceneCode.GDInventoryObjects1});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDDrillHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDWindmillHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDShieldHObjects1Objects = Hashtable.newFrom({"SolarH": gdjs.Planet_95sceneCode.GDSolarHObjects1, "DrillH": gdjs.Planet_95sceneCode.GDDrillHObjects1, "WindmillH": gdjs.Planet_95sceneCode.GDWindmillHObjects1, "ShieldH": gdjs.Planet_95sceneCode.GDShieldHObjects1});
gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects1Objects = Hashtable.newFrom({"Inventory": gdjs.Planet_95sceneCode.GDInventoryObjects1});
gdjs.Planet_95sceneCode.eventsList18 = function(runtimeScene) {

};gdjs.Planet_95sceneCode.eventsList19 = function(runtimeScene) {

};gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDRocksObjects1Objects = Hashtable.newFrom({"Rocks": gdjs.Planet_95sceneCode.GDRocksObjects1});
gdjs.Planet_95sceneCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Ship_Access"), gdjs.Planet_95sceneCode.GDShip_9595AccessObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDPlayerObjects1Objects, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDShip_95959595AccessObjects1Objects, 50, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Planet_95sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.Planet_95sceneCode.eventsList7(runtimeScene);
}


{


gdjs.Planet_95sceneCode.eventsList11(runtimeScene);
}


{


gdjs.Planet_95sceneCode.eventsList12(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("AstroText"), gdjs.Planet_95sceneCode.GDAstroTextObjects1);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDAstroTextObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDAstroTextObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber()));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnergyText"), gdjs.Planet_95sceneCode.GDEnergyTextObjects1);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDEnergyTextObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDEnergyTextObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber()));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("RepairText"), gdjs.Planet_95sceneCode.GDRepairTextObjects1);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDRepairTextObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDRepairTextObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber()));
}
}
}

}


{


gdjs.Planet_95sceneCode.eventsList15(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("InventoryText"), gdjs.Planet_95sceneCode.GDInventoryTextObjects1);

for (gdjs.Planet_95sceneCode.forEachIndex2 = 0;gdjs.Planet_95sceneCode.forEachIndex2 < gdjs.Planet_95sceneCode.GDInventoryTextObjects1.length;++gdjs.Planet_95sceneCode.forEachIndex2) {
gdjs.Planet_95sceneCode.GDInventoryTextObjects2.length = 0;


gdjs.Planet_95sceneCode.forEachTemporary2 = gdjs.Planet_95sceneCode.GDInventoryTextObjects1[gdjs.Planet_95sceneCode.forEachIndex2];
gdjs.Planet_95sceneCode.GDInventoryTextObjects2.push(gdjs.Planet_95sceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Planet_95sceneCode.eventsList17(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DrillH"), gdjs.Planet_95sceneCode.GDDrillHObjects1);
gdjs.copyArray(runtimeScene.getObjects("Inventory"), gdjs.Planet_95sceneCode.GDInventoryObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShieldH"), gdjs.Planet_95sceneCode.GDShieldHObjects1);
gdjs.copyArray(runtimeScene.getObjects("SolarH"), gdjs.Planet_95sceneCode.GDSolarHObjects1);
gdjs.copyArray(runtimeScene.getObjects("WindmillH"), gdjs.Planet_95sceneCode.GDWindmillHObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDDrillHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDWindmillHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDShieldHObjects1Objects, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDDrillHObjects1 */
/* Reuse gdjs.Planet_95sceneCode.GDShieldHObjects1 */
/* Reuse gdjs.Planet_95sceneCode.GDSolarHObjects1 */
/* Reuse gdjs.Planet_95sceneCode.GDWindmillHObjects1 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DrillH"), gdjs.Planet_95sceneCode.GDDrillHObjects1);
gdjs.copyArray(runtimeScene.getObjects("Inventory"), gdjs.Planet_95sceneCode.GDInventoryObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShieldH"), gdjs.Planet_95sceneCode.GDShieldHObjects1);
gdjs.copyArray(runtimeScene.getObjects("SolarH"), gdjs.Planet_95sceneCode.GDSolarHObjects1);
gdjs.copyArray(runtimeScene.getObjects("WindmillH"), gdjs.Planet_95sceneCode.GDWindmillHObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDSolarHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDDrillHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDWindmillHObjects1ObjectsGDgdjs_9546Planet_959595sceneCode_9546GDShieldHObjects1Objects, gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDInventoryObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Planet_95sceneCode.GDDrillHObjects1 */
/* Reuse gdjs.Planet_95sceneCode.GDShieldHObjects1 */
/* Reuse gdjs.Planet_95sceneCode.GDSolarHObjects1 */
/* Reuse gdjs.Planet_95sceneCode.GDWindmillHObjects1 */
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarHObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillHObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillHObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldHObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldHObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BUild"), gdjs.Planet_95sceneCode.GDBUildObjects1);
gdjs.copyArray(runtimeScene.getObjects("Craft"), gdjs.Planet_95sceneCode.GDCraftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Drill"), gdjs.Planet_95sceneCode.GDDrillObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rocks"), gdjs.Planet_95sceneCode.GDRocksObjects1);
gdjs.copyArray(runtimeScene.getObjects("Shield"), gdjs.Planet_95sceneCode.GDShieldObjects1);
gdjs.copyArray(runtimeScene.getObjects("Solar"), gdjs.Planet_95sceneCode.GDSolarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Windmill"), gdjs.Planet_95sceneCode.GDWindmillObjects1);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDPlayerObjects1[i].setZOrder((gdjs.Planet_95sceneCode.GDPlayerObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDWindmillObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDWindmillObjects1[i].setZOrder((gdjs.Planet_95sceneCode.GDWindmillObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDSolarObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSolarObjects1[i].setZOrder((gdjs.Planet_95sceneCode.GDSolarObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDShieldObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDShieldObjects1[i].setZOrder((gdjs.Planet_95sceneCode.GDShieldObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDDrillObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDDrillObjects1[i].setZOrder((gdjs.Planet_95sceneCode.GDDrillObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDRocksObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDRocksObjects1[i].setZOrder((gdjs.Planet_95sceneCode.GDRocksObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDCraftObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDCraftObjects1[i].setZOrder((gdjs.Planet_95sceneCode.GDCraftObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Planet_95sceneCode.GDBUildObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDBUildObjects1[i].setZOrder((gdjs.Planet_95sceneCode.GDBUildObjects1[i].getPointY("")));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Planet_floor"), gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects1[i].setZOrder((( gdjs.Planet_95sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Planet_95sceneCode.GDPlayerObjects1[0].getZOrder()) - 1000);
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.Planet_95sceneCode.GDFireObjects1);

for (gdjs.Planet_95sceneCode.forEachIndex2 = 0;gdjs.Planet_95sceneCode.forEachIndex2 < gdjs.Planet_95sceneCode.GDFireObjects1.length;++gdjs.Planet_95sceneCode.forEachIndex2) {
gdjs.Planet_95sceneCode.GDFireObjects2.length = 0;


gdjs.Planet_95sceneCode.forEachTemporary2 = gdjs.Planet_95sceneCode.GDFireObjects1[gdjs.Planet_95sceneCode.forEachIndex2];
gdjs.Planet_95sceneCode.GDFireObjects2.push(gdjs.Planet_95sceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDFireObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDFireObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.randomInRange(0, 2));
}
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Smoke"), gdjs.Planet_95sceneCode.GDSmokeObjects1);

for (gdjs.Planet_95sceneCode.forEachIndex2 = 0;gdjs.Planet_95sceneCode.forEachIndex2 < gdjs.Planet_95sceneCode.GDSmokeObjects1.length;++gdjs.Planet_95sceneCode.forEachIndex2) {
gdjs.Planet_95sceneCode.GDSmokeObjects2.length = 0;


gdjs.Planet_95sceneCode.forEachTemporary2 = gdjs.Planet_95sceneCode.GDSmokeObjects1[gdjs.Planet_95sceneCode.forEachIndex2];
gdjs.Planet_95sceneCode.GDSmokeObjects2.push(gdjs.Planet_95sceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDSmokeObjects2.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDSmokeObjects2[i].getBehavior("Opacity").setOpacity(gdjs.Planet_95sceneCode.GDSmokeObjects2[i].getBehavior("Opacity").getOpacity() / (2));
}
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Planet_95sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rocks"), gdjs.Planet_95sceneCode.GDRocksObjects1);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDPlayerObjects1[i].separateFromObjectsList(gdjs.Planet_95sceneCode.mapOfGDgdjs_9546Planet_959595sceneCode_9546GDRocksObjects1Objects, false);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("REsource"), gdjs.Planet_95sceneCode.GDREsourceObjects1);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDREsourceObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDREsourceObjects1[i].SetValue(runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber(), null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Energy"), gdjs.Planet_95sceneCode.GDEnergyObjects1);
{for(var i = 0, len = gdjs.Planet_95sceneCode.GDEnergyObjects1.length ;i < len;++i) {
    gdjs.Planet_95sceneCode.GDEnergyObjects1[i].SetValue(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber(), null);
}
}
}

}


};

gdjs.Planet_95sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Planet_95sceneCode.GDPlayerObjects1.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects2.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects3.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects4.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects5.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects6.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects7.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects1.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects2.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects3.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects4.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects5.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects6.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects7.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects1.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects2.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects3.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects4.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects5.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects6.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects7.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects1.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects2.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects3.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects4.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects5.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects6.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects7.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects1.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects2.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects3.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects4.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects5.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects6.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects7.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects1.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects2.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects3.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects4.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects5.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects6.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects7.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects1.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects2.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects3.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects4.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects5.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects6.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects7.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects1.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects2.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects3.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects4.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects5.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects6.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects7.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects1.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects2.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects3.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects4.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects5.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects6.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects7.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects1.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects2.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects3.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects4.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects5.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects6.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects7.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects1.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects2.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects3.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects4.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects5.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects6.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects7.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects1.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects2.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects3.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects4.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects5.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects6.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects7.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects1.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects2.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects3.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects4.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects5.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects6.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects7.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects1.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects2.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects3.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects4.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects5.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects6.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects7.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects1.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects2.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects3.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects4.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects5.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects6.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects7.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects7.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects1.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects2.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects3.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects4.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects5.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects6.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects7.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects1.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects2.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects3.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects4.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects5.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects6.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects7.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects1.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects2.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects3.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects4.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects5.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects6.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects7.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects1.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects2.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects3.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects4.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects5.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects6.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects7.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects1.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects2.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects3.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects4.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects5.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects6.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects7.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects1.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects2.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects3.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects4.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects5.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects6.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects7.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects1.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects2.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects3.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects4.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects5.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects6.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects7.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects1.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects2.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects3.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects4.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects5.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects6.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects7.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects1.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects2.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects3.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects4.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects5.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects6.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects7.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects1.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects2.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects3.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects4.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects5.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects6.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects7.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects1.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects2.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects3.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects4.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects5.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects6.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects7.length = 0;

gdjs.Planet_95sceneCode.eventsList20(runtimeScene);
gdjs.Planet_95sceneCode.GDPlayerObjects1.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects2.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects3.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects4.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects5.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects6.length = 0;
gdjs.Planet_95sceneCode.GDPlayerObjects7.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects1.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects2.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects3.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects4.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects5.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects6.length = 0;
gdjs.Planet_95sceneCode.GDShip_9595AccessObjects7.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects1.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects2.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects3.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects4.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects5.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects6.length = 0;
gdjs.Planet_95sceneCode.GDInventoryObjects7.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects1.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects2.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects3.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects4.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects5.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects6.length = 0;
gdjs.Planet_95sceneCode.GDSolarObjects7.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects1.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects2.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects3.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects4.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects5.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects6.length = 0;
gdjs.Planet_95sceneCode.GDSolarHObjects7.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects1.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects2.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects3.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects4.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects5.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects6.length = 0;
gdjs.Planet_95sceneCode.GDDrillHObjects7.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects1.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects2.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects3.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects4.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects5.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects6.length = 0;
gdjs.Planet_95sceneCode.GDDrillObjects7.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects1.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects2.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects3.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects4.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects5.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects6.length = 0;
gdjs.Planet_95sceneCode.GDWindmillHObjects7.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects1.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects2.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects3.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects4.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects5.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects6.length = 0;
gdjs.Planet_95sceneCode.GDWindmillObjects7.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects1.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects2.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects3.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects4.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects5.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects6.length = 0;
gdjs.Planet_95sceneCode.GDShieldHObjects7.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects1.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects2.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects3.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects4.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects5.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects6.length = 0;
gdjs.Planet_95sceneCode.GDShieldObjects7.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects1.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects2.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects3.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects4.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects5.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects6.length = 0;
gdjs.Planet_95sceneCode.GDCraftObjects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyObjects7.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects1.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects2.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects3.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects4.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects5.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects6.length = 0;
gdjs.Planet_95sceneCode.GDCloseBuyObjects7.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects1.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects2.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects3.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects4.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects5.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects6.length = 0;
gdjs.Planet_95sceneCode.GDRocksObjects7.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects1.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects2.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects3.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects4.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects5.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects6.length = 0;
gdjs.Planet_95sceneCode.GDtransObjects7.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDInventoryTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyText2Objects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyText3Objects7.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects1.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects2.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects3.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects4.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects5.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects6.length = 0;
gdjs.Planet_95sceneCode.GDBuyText4Objects7.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects1.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects2.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects3.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects4.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects5.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects6.length = 0;
gdjs.Planet_95sceneCode.GDBUildObjects7.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects1.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects2.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects3.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects4.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects5.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects6.length = 0;
gdjs.Planet_95sceneCode.GDCloseCraftObjects7.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects1.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects2.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects3.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects4.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects5.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects6.length = 0;
gdjs.Planet_95sceneCode.GDOxygenBarObjects7.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects1.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects2.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects3.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects4.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects5.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects6.length = 0;
gdjs.Planet_95sceneCode.GDMainRocketObjects7.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects1.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects2.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects3.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects4.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects5.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects6.length = 0;
gdjs.Planet_95sceneCode.GDFireObjects7.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects1.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects2.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects3.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects4.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects5.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects6.length = 0;
gdjs.Planet_95sceneCode.GDSmokeObjects7.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects1.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects2.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects3.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects4.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects5.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects6.length = 0;
gdjs.Planet_95sceneCode.GDREsourceObjects7.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects1.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects2.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects3.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects4.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects5.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects6.length = 0;
gdjs.Planet_95sceneCode.GDEnergyObjects7.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDAstroTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDEnergyTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects1.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects2.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects3.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects4.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects5.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects6.length = 0;
gdjs.Planet_95sceneCode.GDRepairTextObjects7.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects1.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects2.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects3.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects4.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects5.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects6.length = 0;
gdjs.Planet_95sceneCode.GDAstroCurrency2Objects7.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects1.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects2.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects3.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects4.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects5.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects6.length = 0;
gdjs.Planet_95sceneCode.GDBulletObjects7.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects1.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects2.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects3.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects4.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects5.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects6.length = 0;
gdjs.Planet_95sceneCode.GDPlanet_9595floorObjects7.length = 0;


return;

}

gdjs['Planet_95sceneCode'] = gdjs.Planet_95sceneCode;
